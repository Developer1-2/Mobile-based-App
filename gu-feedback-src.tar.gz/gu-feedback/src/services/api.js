const BASE_URL = 'http://localhost:8000'

async function handleResponse(res) {
  if (!res.ok) {
    let message = `Error ${res.status}`
    try {
      const data = await res.json()
      message = data.detail || data.message || message
    } catch {}
    throw new Error(message)
  }
  return res.json()
}

export async function submitSuggestion(payload) {
  const res = await fetch(`${BASE_URL}/suggestions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
  return handleResponse(res)
}

export async function trackSuggestion(trackingCode) {
  const res = await fetch(`${BASE_URL}/suggestions/${encodeURIComponent(trackingCode)}`)
  if (res.status === 404) throw new Error('NOT_FOUND')
  return handleResponse(res)
}
