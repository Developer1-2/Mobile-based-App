import { useState, useEffect, useRef } from 'react'

// Lightweight debounced similar suggestions hook
// In production, this would query a lightweight backend endpoint
// For demo, returns mock similar suggestions based on keywords

const MOCK_SIMILAR = [
  { id: 1, title: 'Library closing time should be extended', category: 'Facilities', status: 'In Progress' },
  { id: 2, title: 'WiFi in hostels is very slow during peak hours', category: 'WiFi', status: 'Pending' },
  { id: 3, title: 'Lecture timetable conflicts need to be resolved', category: 'Academics', status: 'Resolved' },
  { id: 4, title: 'Administration response times need improvement', category: 'Administration', status: 'In Progress' },
  { id: 5, title: 'More power outlets needed in the library', category: 'Facilities', status: 'Pending' },
  { id: 6, title: 'Course materials should be uploaded earlier', category: 'Academics', status: 'Pending' },
  { id: 7, title: 'Campus WiFi password changes without notice', category: 'WiFi', status: 'Resolved' },
  { id: 8, title: 'Registration portal is too slow', category: 'Administration', status: 'In Progress' },
  { id: 9, title: 'Cafeteria food quality needs improvement', category: 'Facilities', status: 'Pending' },
  { id: 10, title: 'Exam timetable released too late', category: 'Academics', status: 'Pending' },
]

function scoreMatch(query, item) {
  const q = query.toLowerCase()
  const titleWords = item.title.toLowerCase().split(/\s+/)
  const queryWords = q.split(/\s+/).filter(w => w.length > 2)
  let score = 0
  for (const qw of queryWords) {
    for (const tw of titleWords) {
      if (tw.includes(qw) || qw.includes(tw)) score++
    }
  }
  return score
}

export default function useSimilarSuggestions(query) {
  const [suggestions, setSuggestions] = useState([])
  const timerRef = useRef(null)

  useEffect(() => {
    clearTimeout(timerRef.current)
    if (!query || query.trim().length < 5) {
      setSuggestions([])
      return
    }
    timerRef.current = setTimeout(() => {
      const scored = MOCK_SIMILAR
        .map(item => ({ ...item, score: scoreMatch(query, item) }))
        .filter(item => item.score > 0)
        .sort((a, b) => b.score - a.score)
        .slice(0, 3)
      setSuggestions(scored)
    }, 500)

    return () => clearTimeout(timerRef.current)
  }, [query])

  return suggestions
}
