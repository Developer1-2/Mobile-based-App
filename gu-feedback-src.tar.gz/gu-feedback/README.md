# Gulu University — Student Feedback System

A mobile-first Progressive Web App (PWA) for students at Gulu University to submit and track feedback anonymously.

---

## Features

- 📝 **Submit Feedback** — Title, description, category, anonymous toggle
- 🔍 **Track Suggestions** — Enter tracking code to check status & admin responses
- 💡 **Similar Suggestions** — Lightweight auto-suggest as you type
- 📱 **PWA** — Installable, offline-capable, mobile-first
- 🔒 **Anonymous** — No account required; tracking code system
- ⚡ **Fast** — Optimised for low-bandwidth connections

---

## Tech Stack

| Layer | Tech |
|---|---|
| Framework | React 18 + Vite |
| Routing | React Router v6 |
| API | Fetch API |
| Styling | Plain CSS (design tokens via CSS variables) |
| PWA | vite-plugin-pwa + Workbox |
| Fonts | DM Serif Display + DM Sans (Google Fonts) |

---

## Getting Started

### Prerequisites
- Node.js 18+
- npm or yarn
- Backend API running at `http://localhost:8000`

### Install & Run

```bash
# Install dependencies
npm install

# Start development server
npm run dev
# → http://localhost:3000

# Build for production
npm run build

# Preview production build
npm run preview
```

---

## Project Structure

```
gu-feedback/
├── public/
│   ├── logo.svg              # University logo (SVG)
│   ├── manifest.json         # PWA manifest
│   ├── sw.js                 # Service worker (offline support)
│   ├── offline.html          # Offline fallback page
│   └── icons/
│       ├── icon-192.png      # PWA icon 192×192
│       └── icon-512.png      # PWA icon 512×512
├── src/
│   ├── main.jsx              # Entry point
│   ├── App.jsx               # Root component, routing, splash logic
│   ├── styles/
│   │   └── global.css        # Global design system & CSS variables
│   ├── components/
│   │   ├── SplashScreen.jsx  # 2.5s branded splash on load
│   │   ├── SplashScreen.css
│   │   ├── Navbar.jsx        # Top navigation bar
│   │   └── Navbar.css
│   ├── pages/
│   │   ├── Home.jsx          # Landing page with CTA buttons
│   │   ├── Home.css
│   │   ├── Submit.jsx        # Feedback submission form
│   │   ├── Submit.css
│   │   ├── Track.jsx         # Tracking code lookup
│   │   └── Track.css
│   ├── services/
│   │   └── api.js            # API layer (submitSuggestion, trackSuggestion)
│   └── hooks/
│       └── useSimilarSuggestions.js  # Debounced similar-suggestions hook
├── scripts/
│   └── gen-icons.js          # Helper to generate PWA icons
├── vite.config.js
├── package.json
└── index.html
```

---

## API Integration

**Base URL:** `http://localhost:8000`

### POST `/suggestions`
```json
{
  "title": "Library closing time should be extended",
  "description": "The library closes at 8pm which is too early for students who have evening lectures.",
  "category": "Facilities",
  "anonymous": true
}
```
**Response:**
```json
{
  "tracking_code": "GU-2024-ABCDE",
  "title": "Library closing time should be extended",
  "category": "Facilities",
  "status": "pending"
}
```

### GET `/suggestions/{tracking_code}`
**Response:**
```json
{
  "tracking_code": "GU-2024-ABCDE",
  "title": "Library closing time should be extended",
  "description": "...",
  "category": "Facilities",
  "status": "in_progress",
  "created_at": "2024-03-15T10:30:00Z",
  "responses": [
    {
      "id": 1,
      "message": "Thank you for your feedback. We are reviewing this request.",
      "created_at": "2024-03-16T09:00:00Z"
    }
  ]
}
```

**Status values:** `pending` | `in_progress` | `resolved`

---

## Design System

CSS variables defined in `src/styles/global.css`:

| Variable | Value | Usage |
|---|---|---|
| `--primary` | `#44A08D` | Eucalyptus — buttons, links, accents |
| `--accent` | `#F4C542` | Picasso — highlights, warnings |
| `--background` | `#FFFFFF` | Page background |
| `--text` | `#1a2e28` | Body text |
| `--font-display` | DM Serif Display | Headings |
| `--font-body` | DM Sans | Body text |

---

## PWA Setup

For full PWA support including install prompts:

1. **Generate real PNG icons** from `public/logo.svg`:
   ```bash
   # Using sharp CLI or similar
   npx @squoosh/cli --resize '{"width":192}' -d public/icons public/logo.svg
   ```
   Place `icon-192.png` and `icon-512.png` in `public/icons/`.

2. **Serve over HTTPS** in production (required for service worker).

3. **Test PWA score** with Chrome DevTools → Lighthouse → PWA audit.

---

## Browser Support

Targets modern mobile browsers: Chrome 90+, Safari 14+, Firefox 88+, Samsung Internet 14+.

---

## License

For Gulu University internal use.
